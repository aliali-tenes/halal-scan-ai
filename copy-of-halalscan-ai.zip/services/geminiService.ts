
import { AnalysisResult } from "../types";

/**
 * خدمة التحليل المحسنة للسرعة والدقة.
 * تتصل الآن بالخادم الوسيط الآمن (Backend Proxy) بدلاً من Gemini مباشرة.
 */
export const analyzeIngredients = async (base64Data: string, isPro: boolean = false): Promise<AnalysisResult> => {
  try {
    // يتصل التطبيق الآن بنقطة النهاية (endpoint) للخادم الوسيط الخاص بنا.
    const response = await fetch('/api/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ base64Data, isPro }),
    });

    if (!response.ok) {
      // إذا فشل الخادم، حاول قراءة رسالة الخطأ منه.
      const errorData = await response.json();
      throw new Error(errorData.error || `خطأ في الخادم: ${response.statusText}`);
    }

    const result = await response.json();
    return result as AnalysisResult;
    
  } catch (error: any) {
    console.error("Frontend Service Error:", error);
    // عرض رسالة الخطأ للمستخدم.
    throw new Error(error.message || "فشل الاتصال بخادم التحليل. يرجى التحقق من اتصالك بالإنترنت.");
  }
};
