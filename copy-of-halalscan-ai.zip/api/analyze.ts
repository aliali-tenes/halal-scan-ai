
// This is a Vercel Serverless Function which acts as a secure backend proxy.
// It protects the API_KEY by never exposing it to the client-side.

import { GoogleGenAI, Type } from "@google/genai";
import type { VercelRequest, VercelResponse } from '@vercel/node';
import { AnalysisResult } from '../types';

export default async function handler(
  req: VercelRequest,
  res: VercelResponse,
) {
  // 1. Security First: Only allow POST requests
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    // 2. Extract data from the frontend request
    const { base64Data, isPro } = req.body;

    if (!base64Data) {
      return res.status(400).json({ error: 'Missing image data (base64Data).' });
    }

    // 3. Initialize the AI client securely on the server
    // The API_KEY is stored as an environment variable on Vercel, not in the code.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const modelName = isPro ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';

    const systemInstruction = `
      أنت خبير كيمياء أغذية وفقيه متخصص في الرقابة على المنتجات الحلال.
      مهمتك: استخراج المكونات من الصورة بدقة 100% وتصنيفها شرعياً.
      
      القواعد الصارمة:
      - ابحث عن مشتقات الخنزير (جيلاتين، شحم، كولاجين خنزيري).
      - ابحث عن الكحول والمشروبات الروحية.
      - حلل المضافات (E-Numbers) وصنفها (حلال، حرام، مشتبه) بناءً على المصدر.
      - إذا كان هناك مكون مشبوه مثل (مستحلبات، أحماض دهنية) ولم يحدد المصدر، صنفه كمشتبه.
      - اجعل التوصية النهائية مختصرة ومباشرة.
    `;
    
    // 4. Call the Gemini API from the backend
    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
          { text: "حلل هذه الصورة واستخرج المكونات وصنف حالتها الشرعية بدقة وسرعة." }
        ]
      },
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        thinkingConfig: { thinkingBudget: isPro ? 1024 : 0 },
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            status: { type: Type.STRING, description: "halal, haram, or doubtful" },
            ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            haramIngredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            doubtfulIngredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            eNumberDetails: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  code: { type: Type.STRING },
                  name: { type: Type.STRING },
                  status: { type: Type.STRING },
                  source: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ["code", "name", "status", "source", "description"]
              }
            },
            reason: { type: Type.STRING },
            alternatives: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendation: { type: Type.STRING }
          },
          required: ["status", "ingredients", "haramIngredients", "doubtfulIngredients", "reason", "recommendation"]
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
       return res.status(500).json({ error: "لم يتم استلام بيانات من المحلل." });
    }
    
    const resultJson = JSON.parse(resultText.trim()) as AnalysisResult;
    
    // 5. Send the result back to the frontend
    return res.status(200).json(resultJson);

  } catch (error: any) {
    console.error("Backend Analysis Error:", error);
    // Send a generic error message to the user
    return res.status(500).json({ error: "فشل التحليل. تأكد من جودة الصورة وحاول مرة أخرى." });
  }
}
