
import React, { useState, useEffect } from 'react';

const LoadingOverlay: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);
  const messages = [
    "جاري معالجة الصورة...",
    "جاري قراءة النصوص...",
    "تحليل المضافات الغذائية...",
    "مطابقة المكونات شرعياً...",
    "توليد التوصية النهائية..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % messages.length);
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-[250] p-6 animate-in fade-in duration-300">
      <div className="bg-white rounded-[3rem] p-10 max-w-xs w-full text-center space-y-8 shadow-[0_30px_100px_rgba(0,0,0,0.5)] border border-white/20">
        
        <div className="relative w-24 h-24 mx-auto">
          {/* Inner pulse */}
          <div className="absolute inset-0 bg-emerald-100 rounded-full animate-ping opacity-20"></div>
          
          {/* Spinner */}
          <svg className="w-full h-full animate-spin text-emerald-500" viewBox="0 0 100 100">
            <circle className="opacity-10" cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="8" fill="none" />
            <path className="opacity-90" fill="currentColor" d="M50 10A40 40 0 0 1 90 50h-8a32 32 0 0 0-32-32V10z" />
          </svg>
          
          {/* Center icon */}
          <div className="absolute inset-0 flex items-center justify-center">
            <svg className="w-8 h-8 text-emerald-600 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-2xl font-black text-slate-800 tracking-tight">ذكاء اصطناعي فائق</h3>
          <p className="text-emerald-600 font-black text-sm transition-all duration-500 min-h-[1.5rem]">
            {messages[messageIndex]}
          </p>
        </div>

        <div className="flex justify-center gap-1.5 pt-2">
          {[0, 1, 2].map((i) => (
            <div 
              key={i} 
              className={`w-2.5 h-2.5 bg-emerald-500 rounded-full animate-bounce`} 
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default LoadingOverlay;
