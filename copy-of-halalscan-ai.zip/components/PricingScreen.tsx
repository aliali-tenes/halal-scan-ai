
import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';

// Load the Stripe object with your publishable key.
// This key is safe to be exposed on the client-side.
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY as string);

interface PricingScreenProps {
  onBack: () => void;
}

const PricingScreen: React.FC<PricingScreenProps> = ({ onBack }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const plans = [
    {
      name: 'الباقة الشهرية',
      price: '$3.99',
      period: 'شهرياً',
      priceId: process.env.NEXT_PUBLIC_STRIPE_MONTHLY_PRICE_ID, // e.g., price_12345...
      features: ['تحليل غير محدود', 'دقة Gemini Pro', 'أولوية في الدعم'],
      primary: false,
    },
    {
      name: 'الباقة السنوية',
      price: '$39.99',
      period: 'سنوياً',
      priceId: process.env.NEXT_PUBLIC_STRIPE_YEARLY_PRICE_ID, // e.g., price_67890...
      features: ['كل مزايا الشهرية', 'توفير شهرين', 'وصول للميزات التجريبية'],
      primary: true,
    }
  ];

  const handleCheckout = async (priceId: string | undefined) => {
    if (!priceId) {
      setError("لم يتم تكوين معرف السعر. يرجى الاتصال بالدعم.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // 1. Create a checkout session on our backend
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ priceId }),
      });

      const session = await response.json();

      if (!response.ok) {
        throw new Error(session.error || 'فشل في إنشاء جلسة الدفع.');
      }

      // 2. Redirect to Stripe's hosted checkout page
      const stripe = await stripePromise;
      if (stripe) {
        const { error } = await stripe.redirectToCheckout({
          sessionId: session.sessionId,
        });
        if (error) {
          throw new Error(error.message);
        }
      }
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-left-8 duration-500">
      <div className="text-center md:text-right">
        <h3 className="text-3xl font-black text-slate-900">اختر باقتك الاحترافية</h3>
        <p className="text-slate-500 mt-2">انضم للنسخة الاحترافية واحصل على تحليل فائق الدقة</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {plans.map((plan) => (
          <div key={plan.name} className={`p-6 rounded-3xl border-4 relative overflow-hidden shadow-lg ${plan.primary ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 bg-white'}`}>
            {plan.primary && <div className="absolute top-0 left-0 bg-emerald-500 text-white px-4 py-1 rounded-br-2xl text-[10px] font-black uppercase tracking-widest">الأكثر توفيراً</div>}
            
            <div className="flex justify-between items-center mb-4 mt-4">
              <span className={`font-black text-xl ${plan.primary ? 'text-emerald-700' : 'text-slate-800'}`}>{plan.name}</span>
              <span className={`text-2xl font-black ${plan.primary ? 'text-emerald-600' : 'text-slate-900'}`}>{plan.price}<span className="text-sm opacity-60">/{plan.period}</span></span>
            </div>
            
            <ul className={`text-sm space-y-2 font-bold mb-6 ${plan.primary ? 'text-emerald-700/80' : 'text-slate-500'}`}>
              {plan.features.map(feat => <li key={feat} className="flex items-center gap-2">✅ {feat}</li>)}
            </ul>
            
            <button 
              onClick={() => handleCheckout(plan.priceId)}
              disabled={loading}
              className={`w-full py-4 rounded-xl font-black shadow-lg transition-all disabled:opacity-50 ${plan.primary ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-900 text-white hover:bg-black'}`}
            >
              {loading ? '...جاري التحضير' : 'اشترك الآن'}
            </button>
          </div>
        ))}
      </div>
      
      {error && <p className="text-red-500 text-xs text-center font-bold">{error}</p>}

      <button onClick={onBack} className="text-slate-400 text-sm font-black hover:text-slate-600 transition-colors mx-auto block">
        &larr; العودة للخلف
      </button>
    </div>
  );
};

export default PricingScreen;
