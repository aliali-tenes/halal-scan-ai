
import React, { useState } from 'react';
import PricingScreen from './PricingScreen';

interface AuthScreenProps {
  onUnlock: () => Promise<void>;
  onSkip: () => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onUnlock, onSkip }) => {
  const [view, setView] = useState<'auth' | 'pricing'>('auth');

  return (
    <div className="fixed inset-0 z-[100] bg-slate-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-100 rounded-full blur-[100px] opacity-50"></div>
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-100 rounded-full blur-[100px] opacity-50"></div>
      </div>

      <div className="relative w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 bg-white rounded-3xl shadow-[0_50px_100px_-20px_rgba(0,0,0,0.1)] overflow-hidden border border-white/20">
        
        <div className="hidden md:flex flex-col justify-center items-center bg-emerald-600 p-12 text-white relative">
          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
          <div className="relative z-10 text-center space-y-8">
            <div className="w-24 h-24 bg-white/20 backdrop-blur-xl rounded-3xl flex items-center justify-center mx-auto border border-white/30 animate-bounce-slow shadow-2xl">
               <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
            </div>
            <div className="space-y-4">
              <h2 className="text-4xl font-black leading-tight">بوابة دفع آمنة</h2>
              <p className="text-emerald-100 text-lg opacity-90">نحن نستخدم Stripe لمعالجة المدفوعات. بيانات بطاقتك لا تلمس خوادمنا أبداً، مما يضمن أماناً بنسبة 100%.</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-[10px] font-black uppercase tracking-widest">
              <div className="bg-white/10 p-3 rounded-2xl border border-white/10">PCI Compliant</div>
              <div className="bg-white/10 p-3 rounded-2xl border border-white/10">SSL Encrypted</div>
            </div>
          </div>
        </div>

        <div className="p-8 md:p-16 flex flex-col justify-center">
          {view === 'auth' ? (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-500">
              <div className="text-center md:text-right">
                <h3 className="text-3xl font-black text-slate-900">أطلق العنان للقوة الكاملة</h3>
                <p className="text-slate-500 mt-2">اشترك في النسخة الاحترافية لتحليل أدق وأسرع</p>
              </div>

              <div className="space-y-4">
                <button 
                  onClick={() => setView('pricing')}
                  className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-lg hover:bg-emerald-700 shadow-xl shadow-emerald-200 transition-all transform active:scale-95 flex items-center justify-center gap-3"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                  <span>عرض باقات الاشتراك</span>
                </button>
                <button 
                  onClick={onSkip}
                  className="w-full bg-slate-100 text-slate-600 py-5 rounded-2xl font-black hover:bg-slate-200 transition-all"
                >
                  استمرار بالنسخة الأساسية
                </button>
              </div>

              <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex items-start gap-3">
                <svg className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>
                <p className="text-[11px] text-blue-700 leading-relaxed font-bold">تنبيه: النسخة الأساسية تستخدم نموذج AI أقل قوة وقد تكون محدودة الاستخدام. للحصول على أفضل دقة، نوصي بالاشتراك.</p>
              </div>
            </div>
          ) : (
            <PricingScreen onBack={() => setView('auth')} />
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
