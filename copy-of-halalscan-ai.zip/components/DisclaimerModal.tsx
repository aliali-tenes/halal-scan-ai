
import React from 'react';

interface DisclaimerModalProps {
  onAccept: () => void;
}

const DisclaimerModal: React.FC<DisclaimerModalProps> = ({ onAccept }) => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-500">
      <div className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-white/20 animate-in zoom-in-95 slide-in-from-bottom-10 duration-700">
        
        {/* Header Visual */}
        <div className="bg-amber-500 p-8 text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/pinstriped-suit.png')]"></div>
          <div className="relative z-10 space-y-3">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto border border-white/30 backdrop-blur-md">
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-2xl font-black">تنبيه قانوني وإخلاء مسؤولية</h2>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 md:p-10 space-y-6 text-right">
          <div className="space-y-4 text-slate-600 font-medium leading-relaxed">
            <p className="text-lg text-slate-800 font-black">قبل البدء باستخدام HalalScan، يرجى قراءة ما يلي:</p>
            
            <ul className="space-y-3 text-sm">
              <li className="flex gap-3 items-start">
                <span className="text-amber-500 font-black mt-1">●</span>
                <span>هذا التطبيق يعتمد على تقنيات الذكاء الاصطناعي لتحليل المكونات، والنتائج قد لا تكون دقيقة بنسبة 100% دائماً.</span>
              </li>
              <li className="flex gap-3 items-start">
                <span className="text-amber-500 font-black mt-1">●</span>
                <span>المعلومات المقدمة هي لأغراض استرشادية فقط ولا تعتبر فتوى شرعية أو ضماناً طبياً.</span>
              </li>
              <li className="flex gap-3 items-start">
                <span className="text-amber-500 font-black mt-1">●</span>
                <span className="font-black text-slate-900">المسؤولية الكاملة والقرار النهائي في استهلاك المنتج تقع على عاتق المستهلك وحده.</span>
              </li>
              <li className="flex gap-3 items-start">
                <span className="text-amber-500 font-black mt-1">●</span>
                <span>ننصح دائماً بالتأكد من المكونات يدوياً أو استشارة أهل الاختصاص في الحالات المشتبه بها.</span>
              </li>
            </ul>
          </div>

          <div className="pt-4">
            <button 
              onClick={onAccept}
              className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-lg hover:bg-black shadow-xl transition-all transform active:scale-95"
            >
              أفهم ذلك وأوافق على المتابعة
            </button>
          </div>
        </div>

        {/* Footer Info */}
        <div className="bg-slate-50 py-4 px-8 text-center border-t border-slate-100">
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">
            HalalScan AI Policy v1.0
          </p>
        </div>
      </div>
    </div>
  );
};

export default DisclaimerModal;
