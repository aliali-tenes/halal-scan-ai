
import React from 'react';
import { AnalysisResult, AnalysisStatus, HalalTheme } from '../types';

interface ResultCardProps {
  result: AnalysisResult;
  onReset: () => void;
  currentTheme: HalalTheme;
  onThemeChange: (theme: HalalTheme) => void;
  onShare: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, onReset, currentTheme, onThemeChange, onShare }) => {
  const getStatusConfig = () => {
    if (result.status === AnalysisStatus.HALAL) {
      const baseHalal = {
        label: 'حلال معتمد',
        icon: (
          <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
          </svg>
        )
      };

      switch (currentTheme) {
        case 'teal':
          return { ...baseHalal, bg: 'bg-teal-50', border: 'border-teal-200', text: 'text-teal-700', iconColor: 'text-teal-600', accent: 'bg-teal-500' };
        case 'gold':
          return { ...baseHalal, bg: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-700', iconColor: 'text-orange-600', accent: 'bg-orange-500' };
        case 'blue':
          return { ...baseHalal, bg: 'bg-indigo-50', border: 'border-indigo-200', text: 'text-indigo-700', iconColor: 'text-indigo-600', accent: 'bg-indigo-500' };
        case 'classic':
        default:
          return { ...baseHalal, bg: 'bg-green-50', border: 'border-green-200', text: 'text-green-700', iconColor: 'text-green-600', accent: 'bg-emerald-500' };
      }
    }

    if (result.status === AnalysisStatus.HARAM) {
      return {
        label: 'منتج غير حلال',
        bg: 'bg-red-50',
        border: 'border-red-200',
        text: 'text-red-700',
        iconColor: 'text-red-600',
        accent: 'bg-red-500',
        icon: (
          <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        )
      };
    }

    return {
      label: 'مشتبه به / غير مؤكد',
      bg: 'bg-amber-50',
      border: 'border-amber-200',
      text: 'text-amber-700',
      iconColor: 'text-amber-600',
      accent: 'bg-amber-500',
      icon: (
        <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
      )
    };
  };

  const config = getStatusConfig();

  const themes: { id: HalalTheme; color: string; label: string }[] = [
    { id: 'classic', color: 'bg-emerald-500', label: 'كلاسيك' },
    { id: 'teal', color: 'bg-teal-500', label: 'تيل' },
    { id: 'gold', color: 'bg-orange-500', label: 'ذهبي' },
    { id: 'blue', color: 'bg-indigo-500', label: 'أزرق' },
  ];

  const getENumberStyles = (status: string) => {
    const s = status.toLowerCase();
    if (s.includes('حلال') || s.includes('halal')) {
      return {
        card: 'bg-emerald-50 border-emerald-200 text-emerald-900',
        badge: 'bg-emerald-100 text-emerald-700 border-emerald-200',
        iconBg: 'bg-emerald-500',
        icon: (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
          </svg>
        )
      };
    }
    if (s.includes('حرام') || s.includes('haram')) {
      return {
        card: 'bg-red-50 border-red-200 text-red-900',
        badge: 'bg-red-100 text-red-700 border-red-200',
        iconBg: 'bg-red-500',
        icon: (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" />
          </svg>
        )
      };
    }
    return {
      card: 'bg-amber-50 border-amber-200 text-amber-900',
      badge: 'bg-amber-100 text-amber-700 border-amber-200',
      iconBg: 'bg-amber-500',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
      )
    };
  };

  return (
    <div className={`w-full max-w-2xl mx-auto rounded-3xl border-2 shadow-2xl overflow-hidden transition-all duration-700 ease-[cubic-bezier(0.4,0,0.2,1)] animate-fade-in-up relative ${config.border} ${config.bg}`}>
      
      {result.status === AnalysisStatus.HALAL && (
        <div className="absolute top-6 left-6 flex gap-2 bg-white/50 backdrop-blur-xl p-2.5 rounded-2xl shadow-sm border border-white/40 z-20 hover:bg-white/70 transition-all duration-300">
          {themes.map((t) => (
            <button
              key={t.id}
              onClick={() => onThemeChange(t.id)}
              className={`w-7 h-7 rounded-full border-2 transition-all duration-500 transform hover:scale-125 hover:rotate-6 ${t.color} ${currentTheme === t.id ? 'border-white ring-2 ring-gray-300 scale-110 shadow-lg' : 'border-transparent opacity-60'}`}
              aria-label={t.label}
            />
          ))}
        </div>
      )}

      <div className="p-8 md:p-12 text-center border-b border-inherit pt-20 transition-all duration-700">
        <div className={`inline-flex items-center justify-center p-5 bg-white rounded-full shadow-inner mb-6 transition-all duration-700 transform hover:scale-110 hover:rotate-3 ${config.iconColor}`}>
           <div className="animate-in zoom-in-50 duration-500">
            {config.icon}
           </div>
        </div>
        <h2 className={`text-5xl font-black mb-4 transition-all duration-700 leading-tight ${config.text}`}>
          {config.label}
        </h2>
        <p className="text-gray-600 text-lg font-medium animate-fade-in-up stagger-1 max-w-md mx-auto transition-all duration-500">
          {result.recommendation}
        </p>
      </div>

      <div className="p-6 md:p-8 space-y-8">
        <section className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-white/50 animate-fade-in-up stagger-2 transition-all duration-700">
          <h3 className="font-black text-gray-800 text-lg mb-3 flex items-center gap-2">
            <span className={`w-1.5 h-6 rounded-full transition-all duration-700 ${config.accent}`}></span>
            خلاصة التحليل
          </h3>
          <p className="text-gray-700 leading-relaxed text-lg font-medium transition-colors duration-500">
            {result.reason}
          </p>
        </section>

        {result.haramIngredients.length > 0 && (
          <section className="relative overflow-hidden bg-red-600 rounded-3xl shadow-2xl animate-fade-in-up stagger-3 transform transition-all duration-700 hover:scale-[1.01]">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:20px_20px]"></div>
            
            <div className="relative p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="bg-white p-3 rounded-2xl text-red-600 shadow-xl animate-pulse">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                </div>
                <div className="text-white">
                  <h4 className="text-2xl font-black tracking-tight">مكونات محرمة</h4>
                  <p className="text-red-100 text-sm font-bold opacity-80">تم رصد مشتقات غير حلال قطعية</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {result.haramIngredients.map((ing, i) => (
                  <div key={i} className="flex items-center gap-3 bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl text-white transform hover:translate-x-2 transition-all duration-300 group">
                    <div className="bg-red-500 rounded-lg p-1.5 group-hover:bg-red-400 transition-colors">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </div>
                    <span className="font-black text-lg">{ing}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {result.doubtfulIngredients.length > 0 && (
          <section className="relative overflow-hidden bg-amber-500 rounded-3xl shadow-2xl animate-fade-in-up stagger-3 transform transition-all duration-700 hover:scale-[1.01]">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:20px_20px]"></div>

            <div className="relative p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="bg-white p-3 rounded-2xl text-amber-600 shadow-xl">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div className="text-white">
                  <h4 className="text-2xl font-black tracking-tight">مكونات مشتبهة</h4>
                  <p className="text-amber-100 text-sm font-bold opacity-80">تحتاج تثبّت من المصدر</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {result.doubtfulIngredients.map((ing, i) => (
                  <div key={i} className="flex items-center gap-3 bg-white/15 backdrop-blur-md border border-white/20 p-4 rounded-2xl text-white transform hover:translate-x-2 transition-all duration-300 group">
                    <div className="bg-amber-400 rounded-lg p-1.5 group-hover:bg-amber-300 transition-colors">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M12 9v2m0 4h.01" />
                      </svg>
                    </div>
                    <span className="font-black text-lg">{ing}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {result.eNumberDetails && result.eNumberDetails.length > 0 && (
          <section className="space-y-6 animate-fade-in-up stagger-3">
            <h3 className="font-black text-gray-800 text-xl flex items-center gap-3 px-2">
              <div className="bg-slate-100 p-2.5 rounded-2xl transition-colors duration-500 shadow-sm">
                <svg className="w-6 h-6 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a2 2 0 00-1.96 1.414l-.727 2.903a2 2 0 01-3.156 1.058l-2.436-1.705a2 2 0 00-2.007-.156l-2.612 1.254a2 2 0 01-2.586-1.02l-1.12-2.527a2 2 0 00-1.318-1.15l-2.576-.644a2 2 0 01-1.32-2.31l.527-2.636a2 2 0 00-.318-1.72l-1.8-2.43a2 2 0 01.32-2.73l2.2-1.8a2 2 0 00.6-1.54V4.75a2 2 0 011.66-1.98l2.64-.44a2 2 0 001.4-.82L10.21.6a2 2 0 012.72-.44l2.12 1.48a2 2 0 001.62.26l2.6-.68a2 2 0 012.28 1.44l.64 2.56a2 2 0 001.12 1.32l2.56.64a2 2 0 011.44 2.28l-.68 2.6a2 2 0 00.26 1.62l1.48 2.12a2 2 0 01-.44 2.72l-2.32 1.62z" />
                </svg>
              </div>
              المضافات الغذائية (E-Numbers)
            </h3>
            <div className="grid grid-cols-1 gap-5">
              {result.eNumberDetails.map((item, idx) => {
                const styles = getENumberStyles(item.status);
                return (
                  <div key={idx} className={`border-2 rounded-3xl p-7 shadow-sm transition-all duration-700 hover:scale-[1.02] hover:shadow-xl relative overflow-hidden group ${styles.card}`}>
                    <div className="absolute -right-6 -top-6 w-32 h-32 bg-white/20 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700"></div>
                    
                    <div className="flex flex-col md:flex-row justify-between items-start gap-4 relative z-10">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className={`p-2 rounded-2xl shadow-lg text-white transition-all duration-700 group-hover:rotate-12 ${styles.iconBg}`}>
                            {styles.icon}
                          </div>
                          <span className="text-4xl font-black tracking-tight leading-none transition-colors duration-500">{item.code}</span>
                        </div>
                        <h4 className="text-lg font-black opacity-90 mb-3 transition-colors duration-500">{item.name}</h4>
                        
                        <div className="flex flex-wrap gap-2 mb-4">
                          <span className={`px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-wider border shadow-sm transition-all duration-500 ${styles.badge}`}>
                            {item.status}
                          </span>
                          <div className="flex items-center gap-2 bg-white/50 backdrop-blur-md px-4 py-1.5 rounded-full border border-black/5 transition-colors duration-500">
                            <span className="text-[10px] font-black uppercase opacity-60">المصدر</span>
                            <span className="text-xs font-black">{item.source}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="relative z-10">
                      <p className="text-base leading-relaxed font-bold opacity-80 border-t border-black/5 pt-4 transition-all duration-700">
                        {item.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {result.alternatives && result.alternatives.length > 0 && (
          <section className="bg-white/40 p-8 rounded-3xl border border-white/50 animate-fade-in-up stagger-4 transition-all duration-700 shadow-inner">
            <h3 className="font-black text-gray-800 text-lg mb-5 flex items-center gap-3">
              <div className={`p-2.5 rounded-xl text-white shadow-lg transition-all duration-700 ${config.accent}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              بدائل مقترحة
            </h3>
            <div className="flex flex-wrap gap-3">
              {result.alternatives.map((alt, i) => (
                <span key={i} className={`bg-white px-6 py-3 rounded-2xl text-sm shadow-md border border-inherit font-black transition-all duration-700 hover:scale-105 hover:rotate-1 cursor-default ${config.text}`}>
                  ✨ {alt}
                </span>
              ))}
            </div>
          </section>
        )}

        <div className="bg-white/50 p-4 rounded-2xl text-center mt-6 animate-fade-in-up stagger-4">
            <p className="text-sm font-bold text-slate-600 mb-3">هل كان هذا التحليل مفيداً؟</p>
            <div className="flex justify-center gap-3">
                <button className="bg-emerald-100 text-emerald-700 font-black px-6 py-2 rounded-lg hover:bg-emerald-200 transition-colors">نعم</button>
                <button className="bg-slate-100 text-slate-700 font-black px-6 py-2 rounded-lg hover:bg-slate-200 transition-colors">لا</button>
            </div>
        </div>

        <div className="flex items-center gap-4 mt-8">
            <button 
              onClick={onReset}
              className="w-full bg-slate-900 text-white py-6 rounded-2xl font-black hover:bg-black transition-all duration-500 transform active:scale-95 shadow-2xl flex items-center justify-center gap-4 group overflow-hidden relative"
            >
              <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 skew-x-[-20deg]"></div>
              <span className="text-2xl group-hover:scale-125 transition-transform duration-500 relative z-10">📸</span>
              <span className="text-xl relative z-10">فحص منتج جديد</span>
            </button>
            <button 
              onClick={onShare}
              aria-label="Share result"
              className="flex-shrink-0 bg-emerald-500 text-white w-20 h-20 rounded-2xl font-black hover:bg-emerald-600 transition-all duration-500 transform active:scale-95 shadow-2xl flex items-center justify-center"
            >
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
                </svg>
            </button>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
