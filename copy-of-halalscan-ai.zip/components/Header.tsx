
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="w-full bg-white/80 backdrop-blur-xl border-b border-gray-100 shadow-sm sticky top-0 z-30">
      <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
           <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
             <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
             </svg>
           </div>
           <div>
            <h1 className="text-xl font-black text-slate-800">
              Halal<span className="text-emerald-600">Scan</span>
            </h1>
            <p className="text-xs text-slate-400 font-bold">AI Ingredient Analyzer</p>
           </div>
        </div>
        
        <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100 shadow-sm">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] font-black text-emerald-700 uppercase tracking-tighter">Secure</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
