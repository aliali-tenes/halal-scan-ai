
import React from 'react';

interface InstallPromptProps {
  onInstall: () => void;
  onDismiss: () => void;
}

const InstallPrompt: React.FC<InstallPromptProps> = ({ onInstall, onDismiss }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-[200] p-4 animate-in slide-in-from-bottom-12 duration-500">
      <div 
        className="relative bg-gradient-to-tr from-slate-800 to-slate-900 text-white rounded-3xl shadow-2xl p-6 max-w-md mx-auto border border-white/10 overflow-hidden"
      >
        <div className="absolute -right-10 -top-10 w-32 h-32 bg-emerald-500/20 rounded-full blur-3xl"></div>
        <div className="absolute -left-10 -bottom-10 w-32 h-32 bg-blue-500/20 rounded-full blur-3xl"></div>
        
        <button onClick={onDismiss} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors z-20">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>

        <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-right">
          <div className="flex-shrink-0">
            <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg border-2 border-white/20">
              <svg className="w-9 h-9 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
              </svg>
            </div>
          </div>
          <div className="flex-1">
            <h3 className="font-black text-xl leading-tight">تجربة أفضل على شاشتك الرئيسية</h3>
            <p className="text-sm text-slate-300 mt-1">
              ثبّت التطبيق للوصول السريع والعمل بملء الشاشة، تماماً مثل أي تطبيق آخر.
            </p>
          </div>
          <div className="flex-shrink-0 w-full sm:w-auto">
            <button
              onClick={onInstall}
              className="w-full bg-emerald-500 text-white font-black px-6 py-4 rounded-xl hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20 transform active:scale-95"
            >
              تثبيت التطبيق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstallPrompt;
