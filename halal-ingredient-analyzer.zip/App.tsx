import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { IngredientInput } from './components/IngredientInput';
import { ResultCard } from './components/ResultCard';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ShareButton } from './components/ShareButton';
import { analyzeIngredients, extractTextFromImage, modelDisplayName } from './services/geminiService';
import { Language, translations } from './utils/translations';
import type { AnalysisResult, Status, UserProfile } from './types';
import { InfoCard } from './components/InfoCard';
import { HalalIcon } from './components/icons/HalalIcon';
import { PrivacyModal } from './components/PrivacyModal';
import { FeedbackModal } from './components/FeedbackModal';
import { Toast } from './components/Toast';
import { ProfileModal } from './components/ProfileModal';
import { ReligiousGuidance } from './components/ReligiousGuidance';
import { Onboarding } from './components/Onboarding';
import { OnboardingDemoResults } from './components/OnboardingDemoResults';
import { ImageEditor } from './components/ImageEditor';

export default function App() {
  const [language, setLanguage] = useState<Language>('ar');
  const [ingredientsText, setIngredientsText] = useState<string>('');
  const [results, setResults] = useState<AnalysisResult[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState<boolean>(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [feedbackIngredient, setFeedbackIngredient] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile>({ language: 'ar', concerns: '' });
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(false);
  const [onboardingStep, setOnboardingStep] = useState<number>(0);
  
  // Image Editor state & Queue
  const [imageQueue, setImageQueue] = useState<{file: File, src: string}[]>([]);
  const [editingImageType, setEditingImageType] = useState<string>('image/jpeg');

  const currentTranslations = translations[language];

  useEffect(() => {
    // Load user profile from local storage
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      const profile = JSON.parse(savedProfile);
      setUserProfile(profile);
      setLanguage(profile.language);
    }
  }, []);
  
  // Check for privacy consent and onboarding status on initial load
  useEffect(() => {
      const privacyAccepted = localStorage.getItem('privacyAccepted');
      if (!privacyAccepted) {
          setIsPrivacyModalOpen(true);
      } else {
          const onboardingCompleted = localStorage.getItem('onboardingCompleted');
          if (!onboardingCompleted) {
              setIsOnboardingOpen(true);
          }
      }
  }, []);


  const handleAcceptPrivacy = () => {
    localStorage.setItem('privacyAccepted', 'true');
    setIsPrivacyModalOpen(false);
    const onboardingCompleted = localStorage.getItem('onboardingCompleted');
    if (!onboardingCompleted) {
      setIsOnboardingOpen(true);
    }
  };

  const handleCompleteOnboarding = () => {
    localStorage.setItem('onboardingCompleted', 'true');
    setIsOnboardingOpen(false);
  };

  const handleApiError = (err: unknown, defaultError: string) => {
    console.error(err);
    if (err instanceof Error && (err.message.includes('API key not valid') || err.message.includes('Requested entity was not found.'))) {
        setError(currentTranslations.error_api_generic);
    } else {
        setError(defaultError);
    }
  };

  const handleAnalyze = useCallback(async () => {
    if (!ingredientsText.trim()) {
      setError(currentTranslations.error_empty);
      return;
    }

    setIsLoading(true);
    setError(null);
    setResults([]);

    try {
      const analysis = await analyzeIngredients(ingredientsText, language, userProfile.concerns);
      setResults(analysis);
    } catch (err) {
      handleApiError(err, currentTranslations.error_analysis);
    } finally {
      setIsLoading(false);
    }
  }, [ingredientsText, language, userProfile.concerns, currentTranslations]);

  const handleImageUpload = useCallback(async (files: FileList) => {
    const newItems: {file: File, src: string}[] = [];
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();
        const promise = new Promise<{file: File, src: string}>((resolve) => {
            reader.onloadend = () => {
                resolve({file, src: reader.result as string});
            };
            reader.readAsDataURL(file);
        });
        newItems.push(await promise);
    }

    setImageQueue(prev => [...prev, ...newItems]);
    if (files.length > 0) {
        setEditingImageType(files[0].type);
    }
  }, []);

  const handleImageEditorConfirm = async (base64Data: string) => {
    // Determine mime type of currently editing file
    const currentMime = imageQueue[0]?.file.type || editingImageType;
    
    // Remove the item from queue
    const updatedQueue = [...imageQueue];
    updatedQueue.shift();
    setImageQueue(updatedQueue);

    setIsLoading(true);
    setError(null);

    try {
      const extractedText = await extractTextFromImage(base64Data, currentMime);
      setIngredientsText(prev => {
          const separator = prev.trim() ? ', ' : '';
          return prev + separator + extractedText;
      });
    } catch (err) {
      handleApiError(err, currentTranslations.error_ocr);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenFeedbackModal = (ingredient: string) => {
    setFeedbackIngredient(ingredient);
    setIsFeedbackModalOpen(true);
  };

  const handleCloseFeedbackModal = () => {
    setIsFeedbackModalOpen(false);
    setFeedbackIngredient(null);
  };

  const handleSubmitFeedback = ({ correctStatus, comments }: { correctStatus: Status; comments: string }) => {
    handleCloseFeedbackModal();
    setToastMessage(currentTranslations.feedback_thanks);
  };

  const handleSaveProfile = (newProfile: UserProfile) => {
    setUserProfile(newProfile);
    setLanguage(newProfile.language);
    localStorage.setItem('userProfile', JSON.stringify(newProfile));
    setIsProfileModalOpen(false);
    setToastMessage(translations[newProfile.language].profile_saved);
  };

  const pageDirection = language === 'ar' ? 'rtl' : 'ltr';

  const tourSteps = [
    {
      selector: '[data-tour-id="app-title"]',
      title: currentTranslations.onboarding_welcome_title,
      content: currentTranslations.onboarding_welcome_content,
    },
    {
      selector: '[data-tour-id="language-selector"]',
      title: currentTranslations.onboarding_lang_title,
      content: currentTranslations.onboarding_lang_content,
    },
    {
      selector: '[data-tour-id="ingredient-input-area"]',
      title: currentTranslations.onboarding_step1_title,
      content: currentTranslations.onboarding_step1_content,
    },
    {
      selector: '[data-tour-id="scan-button"]',
      title: currentTranslations.onboarding_scan_title,
      content: currentTranslations.onboarding_scan_content,
    },
    {
      selector: '[data-tour-id="analyze-button"]',
      title: currentTranslations.onboarding_analyze_title,
      content: currentTranslations.onboarding_analyze_content,
    },
    {
      selector: '[data-tour-id="result-card-demo"]',
      title: currentTranslations.onboarding_step2_title,
      content: currentTranslations.onboarding_step2_content,
    },
    {
      selector: '[data-tour-id="profile-button"]',
      title: currentTranslations.onboarding_step3_title,
      content: currentTranslations.onboarding_step3_content,
    },
    {
      selector: '[data-tour-id="guidance-section"]',
      title: currentTranslations.onboarding_guidance_title,
      content: currentTranslations.onboarding_guidance_content,
    },
  ];

  const currentEditingItem = imageQueue[0];

  return (
    <div dir={pageDirection} className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      <Onboarding
        isOpen={isOnboardingOpen}
        steps={tourSteps}
        onComplete={handleCompleteOnboarding}
        translations={currentTranslations}
        onStepChange={setOnboardingStep}
      />
      <PrivacyModal
        isOpen={isPrivacyModalOpen}
        onClose={handleAcceptPrivacy}
        translations={currentTranslations}
      />
      <FeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={handleCloseFeedbackModal}
        onSubmit={handleSubmitFeedback}
        ingredientName={feedbackIngredient}
        translations={currentTranslations}
      />
       <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        onSave={handleSaveProfile}
        currentUserProfile={userProfile}
        translations={currentTranslations}
      />
      {currentEditingItem && (
        <ImageEditor
          imageSrc={currentEditingItem.src}
          onConfirm={handleImageEditorConfirm}
          onClose={() => setImageQueue(prev => prev.slice(1))}
          translations={currentTranslations}
        />
      )}
      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage(null)} />}
      <Header
        language={language}
        setLanguage={setLanguage}
        translations={currentTranslations}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        modelName={modelDisplayName}
      />

      <main className="container mx-auto p-4 md:p-6 max-w-4xl">
        <div className="text-center mb-8" data-tour-id="app-title">
           <div className="inline-block bg-white p-4 rounded-full shadow-md mb-4 border-2 border-brand-green">
            <HalalIcon className="w-16 h-16 text-brand-green" />
           </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-2">
            {currentTranslations.title}
          </h1>
          <p className="text-lg text-gray-600">
            {currentTranslations.subtitle}
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-200">
          <IngredientInput
            value={ingredientsText}
            onChange={setIngredientsText}
            onAnalyze={handleAnalyze}
            onImageUpload={handleImageUpload}
            isLoading={isLoading}
            translations={currentTranslations}
            disabled={isLoading}
          />

          {error && <p className="text-red-500 mt-4 text-center">{error}</p>}
        </div>

        {isLoading && <LoadingSpinner translations={currentTranslations} />}

        {results.length > 0 && (
          <div className="mt-8">
            <div className="flex justify-between items-center mb-4">
               <h2 className="text-2xl font-bold">{currentTranslations.analysis_results}</h2>
               <ShareButton results={results} translations={currentTranslations} />
            </div>
            <div className="space-y-4">
              {results.map((result, index) => (
                <ResultCard
                  key={index}
                  result={result}
                  index={index}
                  translations={currentTranslations}
                  onReportInaccuracy={handleOpenFeedbackModal}
                />
              ))}
            </div>
          </div>
        )}
        
        {!isLoading && results.length === 0 && (
           <>
            {isOnboardingOpen && onboardingStep === 5 && (
              <OnboardingDemoResults translations={currentTranslations} />
            )}
            <InfoCard translations={currentTranslations} />
            <ReligiousGuidance translations={currentTranslations} />
           </>
        )}
      </main>
      
      <footer className="text-center p-4 mt-8 text-gray-500 text-sm">
        <p>{currentTranslations.footer_disclaimer}</p>
        <p>
          <button onClick={() => setIsPrivacyModalOpen(true)} className="underline hover:text-brand-green transition-colors">
            {currentTranslations.privacy_notice_link}
          </button>
        </p>
        <p>&copy; 2024 Halal Analyzer. All rights reserved.</p>
      </footer>
    </div>
  );
}