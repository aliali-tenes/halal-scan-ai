import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import type { AnalysisResult } from '../types';
import type { Language } from '../utils/translations';

// Security: Removed hardcoded API key and switched to process.env.API_KEY to mitigate credential leaking.
// As a security best practice, secrets must be handled through environment variables.
const getAiClient = () => {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};


// Updated to the latest recommended model for complex reasoning and analysis tasks.
export const modelIdentifier = 'gemini-3-flash-preview';
export const modelDisplayName = 'Gemini 3 Flash';

// Security: This prompt acts as a form of protection by strictly defining the AI's role and expected output format.
// It mitigates risks of prompt injection and ensures the AI doesn't deviate to unintended tasks.
const getSystemInstruction = (language: Language, concerns: string): string => {
  const langMap = {
    en: "English",
    ar: "Arabic",
    fr: "French"
  };

  let concernInstruction = '';
  if (concerns && concerns.trim().length > 0) {
    concernInstruction = `\nCRITICAL DIRECTIVE ON USER CONCERNS:
The user has specified the following dietary concerns: "${concerns}".
You are required to give these concerns the highest priority. If an ingredient matches, is derived from, or is related to these concerns, you MUST explicitly state this in the 'reason' field. The presence of a user concern is a critical factor and should strongly influence your judgment, often warranting a 'Mushbooh' or 'Haram' status.`;
  }

  return `You are an expert in Islamic dietary laws (Halal and Haram). Your primary task is to analyze a list of food ingredients and provide a clear judgment on their status.

Core Directives:
1.  For each ingredient, you MUST determine if it is Halal (permissible), Haram (forbidden), or Mushbooh (doubtful).
2.  You MUST provide a brief, clear reason for your determination in ${langMap[language]}.
3.  Your entire response MUST be a valid JSON array of objects, adhering strictly to the provided schema. Do not include any introductory text, markdown, or explanations outside the JSON.

Intelligent Recognition Rules:
1.  **Normalization:** You must normalize recognized ingredient names. If you encounter an abbreviation (e.g., "MSG"), a common misspelling (e.g., "gelitin"), an E-number (e.g., "E120"), or a regional variation (e.g., "coriander leaf" vs "cilantro"), you must process it and return the scientifically or most commonly accepted full name in the 'ingredient' field (e.g., "Monosodium Glutamate", "Gelatin", "Cochineal").
2.  **Transparency:** In the "reason" field, you MUST briefly state how you interpreted the original term if a normalization was performed. For example, for an input of "E120", the reason could start with "Cochineal extract (from E-number E120) is...". For a misspelling like "gelitin", the reason could start with "Identified as Gelatin (from misspelling 'gelitin')...". This builds user trust.
${concernInstruction}

JSON Schema Definition:
The response must be an array of objects, where each object has the following properties:
- "ingredient": string (The normalized, full name of the ingredient)
- "status": string (Must be one of "Halal", "Haram", or "Mushbooh")
- "reason": string (A brief explanation for the status in ${langMap[language]}, including any normalization transparency notes)`;
};


export const analyzeIngredients = async (ingredientsText: string, language: Language, concerns: string): Promise<AnalysisResult[]> => {
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: modelIdentifier,
      contents: `Analyze these ingredients: ${ingredientsText}`,
      config: {
        systemInstruction: getSystemInstruction(language, concerns),
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              ingredient: { type: Type.STRING },
              status: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ["ingredient", "status", "reason"]
          }
        },
        temperature: 0.1
      }
    });

    // Extracting text output as a property as per GenAI SDK guidelines.
    const jsonText = response.text || '[]';
    const parsedResult = JSON.parse(jsonText);

    // Validate the parsed result
    if (Array.isArray(parsedResult)) {
        return parsedResult as AnalysisResult[];
    } else {
        throw new Error("API response is not a valid JSON array.");
    }

  } catch (error) {
    console.error("Error analyzing ingredients:", error);
    // Re-throw the original error to allow for specific error handling upstream (e.g., for invalid API keys).
    throw error;
  }
};


export const extractTextFromImage = async (base64Data: string, mimeType: string): Promise<string> => {
    const imagePart = {
        inlineData: {
            mimeType: mimeType,
            data: base64Data,
        },
    };
    const textPart = {
        text: "Extract all text from this image of a food ingredient list. Return only the extracted text, separated by commas.",
    };

    try {
        const ai = getAiClient();
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: modelIdentifier,
            contents: { parts: [imagePart, textPart] },
        });
        // Accessing response text as a property as required by the latest SDK.
        return (response.text || '').trim();
    } catch (error) {
        console.error("Error extracting text from image:", error);
        // Re-throw for upstream handling
        throw error;
    }
};