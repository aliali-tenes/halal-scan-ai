import React, { useState } from 'react';
import { BookOpenIcon } from './icons/BookOpenIcon';

interface ReligiousGuidanceProps {
    translations: { [key: string]: any };
}

type GuidanceTab = 'core' | 'doubtful' | 'necessity';

const TabButton: React.FC<{
    isActive: boolean;
    onClick: () => void;
    children: React.ReactNode;
}> = ({ isActive, onClick, children }) => (
    <button
        onClick={onClick}
        className={`px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-brand-green focus:ring-offset-2 ${
            isActive
                ? 'bg-brand-green text-white shadow'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
        }`}
    >
        {children}
    </button>
);

const GuidanceContent: React.FC<{title: string, content: string, source: string}> = ({title, content, source}) => (
     <div className="animate-fade-in-up" style={{ animationDuration: '0.3s' }}>
        <h3 className="text-lg font-bold text-gray-800 mb-2">{title}</h3>
        <blockquote className="border-r-4 border-gray-300 pr-4 rtl:border-r-0 rtl:border-l-4 rtl:pr-0 rtl:pl-4">
            <p className="italic">{content}</p>
            <footer className="mt-2 text-sm text-gray-500 font-medium">{source}</footer>
        </blockquote>
    </div>
);


export const ReligiousGuidance: React.FC<ReligiousGuidanceProps> = ({ translations }) => {
    const [activeTab, setActiveTab] = useState<GuidanceTab>('core');

    return (
        <div className="mt-8 bg-gray-100 border-t-4 border-brand-green p-6 rounded-lg text-gray-700" data-tour-id="guidance-section">
            <div className="flex items-center gap-3 mb-4">
                <BookOpenIcon className="w-8 h-8 text-brand-green" />
                <h2 className="text-2xl font-bold text-gray-800">{translations.guidance_title}</h2>
            </div>

            <div className="flex flex-wrap gap-2 mb-6 border-b border-gray-300 pb-4">
                <TabButton isActive={activeTab === 'core'} onClick={() => setActiveTab('core')}>
                    {translations.guidance_tab_core}
                </TabButton>
                <TabButton isActive={activeTab === 'doubtful'} onClick={() => setActiveTab('doubtful')}>
                    {translations.guidance_tab_doubtful}
                </TabButton>
                <TabButton isActive={activeTab === 'necessity'} onClick={() => setActiveTab('necessity')}>
                    {translations.guidance_tab_necessity}
                </TabButton>
            </div>
            
            <div className="space-y-4">
               {activeTab === 'core' && (
                   <div className="space-y-4 animate-fade-in-up" style={{ animationDuration: '0.3s' }}>
                        <blockquote className="border-r-4 border-gray-300 pr-4 rtl:border-r-0 rtl:border-l-4 rtl:pr-0 rtl:pl-4">
                            <p className="italic">"{translations.quran_verse}"</p>
                            <footer className="mt-2 text-sm text-gray-500 font-medium">{translations.quran_source}</footer>
                        </blockquote>
                        <blockquote className="border-r-4 border-gray-300 pr-4 rtl:border-r-0 rtl:border-l-4 rtl:pr-0 rtl:pl-4">
                            <p className="italic">"{translations.hadith_text}"</p>
                            <footer className="mt-2 text-sm text-gray-500 font-medium">{translations.hadith_source}</footer>
                        </blockquote>
                   </div>
               )}
               {activeTab === 'doubtful' && (
                   <GuidanceContent 
                        title={translations.guidance_doubtful_title}
                        content={translations.guidance_doubtful_content}
                        source={translations.guidance_doubtful_source}
                   />
               )}
               {activeTab === 'necessity' && (
                   <GuidanceContent 
                        title={translations.guidance_necessity_title}
                        content={translations.guidance_necessity_content}
                        source={translations.guidance_necessity_source}
                   />
               )}
            </div>
        </div>
    );
};