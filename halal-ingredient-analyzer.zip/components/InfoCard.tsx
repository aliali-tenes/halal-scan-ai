
import React from 'react';
import { InfoIcon } from './icons/InfoIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';


interface InfoCardProps {
    translations: { [key: string]: any };
}

const InfoStep: React.FC<{ step: number; text: string; isRTL: boolean }> = ({ step, text, isRTL }) => (
    <li className="flex items-start gap-3">
        <div className="flex-shrink-0 flex items-center justify-center w-6 h-6 bg-brand-green text-white rounded-full font-bold text-sm">
            {step}
        </div>
        <span className="flex-1">{text}</span>
    </li>
);

export const InfoCard: React.FC<InfoCardProps> = ({ translations }) => {
    const isRTL = document.documentElement.dir === 'rtl';

    return (
        <div className="mt-8 bg-blue-50 border-l-4 border-blue-400 p-6 rounded-lg text-blue-800">
            <div className="flex items-center gap-3 mb-4">
                <InfoIcon className="w-8 h-8 text-blue-500" />
                <h2 className="text-2xl font-bold">{translations.info_title}</h2>
            </div>
            <ul className="space-y-3">
               <InfoStep step={1} text={translations.info_step1} isRTL={isRTL} />
               <InfoStep step={2} text={translations.info_step2} isRTL={isRTL} />
               <InfoStep step={3} text={translations.info_step3} isRTL={isRTL} />
               <InfoStep step={4} text={translations.info_step4} isRTL={isRTL} />
            </ul>
        </div>
    );
};
