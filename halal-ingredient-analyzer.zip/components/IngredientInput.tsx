import React, { useRef } from 'react';
import { CameraIcon } from './icons/CameraIcon';
import { SparklesIcon } from './icons/SparklesIcon';

interface IngredientInputProps {
  value: string;
  onChange: (value: string) => void;
  onAnalyze: () => void;
  onImageUpload: (files: FileList) => void;
  isLoading: boolean;
  translations: { [key: string]: any };
  disabled?: boolean;
}

export const IngredientInput: React.FC<IngredientInputProps> = ({
  value,
  onChange,
  onAnalyze,
  onImageUpload,
  isLoading,
  translations,
  disabled = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCameraClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      onImageUpload(files);
    }
  };
  
  const isAnalyzeDisabled = disabled || isLoading || !value.trim();

  return (
    <div className={disabled ? 'opacity-50 cursor-not-allowed' : ''}>
      <textarea
        data-tour-id="ingredient-input-area"
        className="w-full h-32 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-green focus:outline-none transition duration-200 disabled:bg-gray-100"
        placeholder={translations.input_placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled || isLoading}
      />
      <div className="mt-4 flex flex-col sm:flex-row gap-3">
        <button
          data-tour-id="scan-button"
          onClick={handleCameraClick}
          className="flex-1 flex items-center justify-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white font-bold py-3 px-4 rounded-lg transition duration-200 disabled:bg-orange-300 disabled:cursor-not-allowed"
          disabled={disabled || isLoading}
        >
          <CameraIcon className="w-6 h-6" />
          {translations.scan_button}
        </button>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept="image/*"
          multiple
          capture="environment"
          onChange={handleFileChange}
          disabled={disabled || isLoading}
        />
        <button
          data-tour-id="analyze-button"
          onClick={onAnalyze}
          className="flex-1 flex items-center justify-center gap-2 bg-brand-green hover:bg-brand-green-dark text-white font-bold py-3 px-4 rounded-lg transition duration-200 disabled:bg-green-300 disabled:cursor-not-allowed"
          disabled={isAnalyzeDisabled}
        >
          <SparklesIcon className="w-6 h-6" />
          {translations.analyze_button}
        </button>
      </div>
    </div>
  );
};