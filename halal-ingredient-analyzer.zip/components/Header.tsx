import React from 'react';
import type { Language } from '../utils/translations';
import { HalalIcon } from './icons/HalalIcon';
import { GlobeIcon } from './icons/GlobeIcon';
import { UserIcon } from './icons/UserIcon';

interface HeaderProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  translations: { [key: string]: any };
  onOpenProfile: () => void;
  modelName: string;
}

export const Header: React.FC<HeaderProps> = ({ language, setLanguage, translations, onOpenProfile, modelName }) => {
  return (
    <header className="bg-white shadow-md sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <HalalIcon className="w-8 h-8 text-brand-green" />
          <div className="hidden sm:block">
            <span className="text-xl font-bold text-gray-800">{translations.title}</span>
            <div className="text-xs text-gray-400">
                {translations.powered_by} <span className="font-semibold text-gray-500">{modelName}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
            <div className="relative" data-tour-id="language-selector">
                <GlobeIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 pointer-events-none" />
                <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value as Language)}
                    className="pl-10 pr-4 py-2 bg-gray-100 border border-gray-300 text-gray-700 font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-brand-green appearance-none transition-colors duration-200"
                    aria-label="Select language"
                >
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                    <option value="fr">Français</option>
                </select>
            </div>
            <div data-tour-id="profile-button">
              <button
                  onClick={onOpenProfile}
                  className="p-2 rounded-md hover:bg-gray-200 transition-colors duration-200 text-gray-600"
                  aria-label="Open user preferences"
              >
                  <UserIcon className="w-6 h-6" />
              </button>
            </div>
        </div>
      </div>
    </header>
  );
};