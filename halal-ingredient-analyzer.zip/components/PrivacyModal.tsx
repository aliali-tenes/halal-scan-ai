import React, { useEffect, useRef } from 'react';
import { ShieldCheckIcon } from './icons/ShieldCheckIcon';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  translations: { [key: string]: any };
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose, translations }) => {
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
      modalRef.current?.focus();
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="privacy-modal-title"
    >
      <div
        ref={modalRef}
        className="bg-white rounded-2xl shadow-2xl p-6 md:p-8 max-w-md w-full text-center transform transition-all scale-100 opacity-100"
        tabIndex={-1}
      >
        <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4 border-4 border-white shadow-inner">
          <ShieldCheckIcon className="h-8 w-8 text-brand-green" />
        </div>
        <h2 id="privacy-modal-title" className="text-2xl font-bold text-gray-800 mb-3">
          {translations.privacy_modal_title}
        </h2>
        <p className="text-gray-600 mb-6">
          {translations.privacy_modal_content}
        </p>
        <button
          onClick={onClose}
          className="w-full bg-brand-green hover:bg-brand-green-dark text-white font-bold py-3 px-4 rounded-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-green"
          aria-label={translations.privacy_modal_button}
        >
          {translations.privacy_modal_button}
        </button>
      </div>
    </div>
  );
};
