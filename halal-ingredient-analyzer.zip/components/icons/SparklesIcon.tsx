
import React from 'react';

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M12 3L9.5 8.5L4 11L9.5 13.5L12 19L14.5 13.5L20 11L14.5 8.5L12 3Z"/>
        <path d="M5 21L7 17L9 21"/>
        <path d="M15 21L17 17L19 21"/>
        <path d="M18 5L19 3L20 5"/>
        <path d="M2 11L4 9L2 7"/>
        <path d="M22 11L20 9L22 7"/>
    </svg>
);
