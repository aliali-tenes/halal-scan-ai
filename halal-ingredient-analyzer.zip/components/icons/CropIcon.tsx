import React from 'react';

export const CropIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M6 13V6a3 3 0 0 1 3-3h7"></path>
    <path d="M5 21 21 5"></path>
    <path d="M11 18h7a3 3 0 0 0 3-3V8"></path>
  </svg>
);