
import React from 'react';

export const HalalIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.25 14.5l-3.5-3.5 1.41-1.41L10.75 14.08l5.84-5.83 1.41 1.41-7.25 7.24z" />
        <path d="M6.2 11.5c.36.14.74.22 1.14.22 1.12 0 2.13-.5 2.83-1.3l.3-.34c.3-.34.69-.58 1.1-.7.39-.12.8-.12 1.19 0 .41.12.8.36 1.1.7l.3.34c.7.8 1.7 1.3 2.83 1.3.4 0 .78-.08 1.14-.22-1.45 3.2-4.64 5.5-8.27 5.5s-6.82-2.3-8.27-5.5z" fillOpacity=".3"/>
    </svg>
);
