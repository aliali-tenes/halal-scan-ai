import React from 'react';
import { KeyIcon } from './icons/KeyIcon';
import { SparklesIcon } from './icons/SparklesIcon';

interface ApiKeyPromptProps {
  onSelectKey: () => void;
  translations: { [key: string]: any };
}

export const ApiKeyPrompt: React.FC<ApiKeyPromptProps> = ({ onSelectKey, translations }) => {
  return (
    <div className="bg-white border-2 border-yellow-400 p-6 sm:p-8 rounded-2xl text-center mb-6 animate-fade-in-up shadow-lg">
      <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-yellow-100 mb-4">
          <KeyIcon className="w-8 h-8 text-yellow-600" />
      </div>
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">{translations.api_key_prompt_title}</h2>
      <p className="text-gray-600 my-4 max-w-lg mx-auto">{translations.api_key_prompt_content}</p>
      <div className="mt-6 flex flex-col items-center gap-4">
        <button
          onClick={onSelectKey}
          className="flex items-center justify-center gap-2 w-full sm:w-auto bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-3 px-6 rounded-lg transition duration-200 text-lg shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
        >
          <SparklesIcon className="w-6 h-6" />
          {translations.api_key_prompt_button}
        </button>
        <a 
          href="https://ai.google.dev/gemini-api/docs/billing" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-sm text-yellow-800 underline hover:text-yellow-900"
        >
          {translations.api_key_prompt_link}
        </a>
      </div>
    </div>
  );
};