import React from 'react';
import type { AnalysisResult, Status } from '../types';
import { HalalSealIcon } from './icons/HalalSealIcon';
import { HaramSealIcon } from './icons/HaramSealIcon';
import { MushboohSealIcon } from './icons/MushboohSealIcon';
import { ThumbsDownIcon } from './icons/ThumbsDownIcon';

interface ResultCardProps {
  result: AnalysisResult;
  index: number;
  translations: { [key: string]: any };
  onReportInaccuracy: (ingredient: string) => void;
}

const statusStyles: { [key in Status]: { bg: string; text: string; border: string; icon: React.ReactNode; iconContainerBg: string; } } = {
  Halal: {
    bg: 'bg-green-50',
    text: 'text-green-900',
    border: 'border-green-400',
    icon: <HalalSealIcon className="w-7 h-7 text-green-700" />,
    iconContainerBg: 'bg-green-200'
  },
  Haram: {
    bg: 'bg-red-50',
    text: 'text-red-900',
    border: 'border-red-400',
    icon: <HaramSealIcon className="w-7 h-7 text-red-700" />,
    iconContainerBg: 'bg-red-200'
  },
  Mushbooh: {
    bg: 'bg-yellow-50',
    text: 'text-yellow-900',
    border: 'border-yellow-400',
    icon: <MushboohSealIcon className="w-7 h-7 text-yellow-700" />,
    iconContainerBg: 'bg-yellow-200'
  },
};

const getStatusTranslation = (status: Status, translations: { [key: string]: any }): string => {
    switch(status) {
        case 'Halal': return translations.status_halal;
        case 'Haram': return translations.status_haram;
        case 'Mushbooh': return translations.status_mushbooh;
        default: return status;
    }
}


export const ResultCard: React.FC<ResultCardProps> = ({ result, index, translations, onReportInaccuracy }) => {
  const styles = statusStyles[result.status] || statusStyles.Mushbooh;

  return (
    <div
      className={`p-4 sm:p-5 rounded-xl border-l-4 ${styles.bg} ${styles.border} ${styles.text} shadow-sm transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1 hover:scale-[1.02] opacity-0 animate-fade-in-up`}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="flex items-center gap-4">
        <div className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center ${styles.iconContainerBg} animate-icon-pulse`}>
          {styles.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-center gap-2">
            <h3 className="font-bold text-lg truncate" title={result.ingredient}>{result.ingredient}</h3>
            <div className="flex items-center gap-2 flex-shrink-0">
                <span className={`px-2.5 py-1 text-xs font-bold uppercase tracking-wider rounded-full ${styles.iconContainerBg} ${styles.text}`}>{getStatusTranslation(result.status, translations)}</span>
                <button
                    onClick={() => onReportInaccuracy(result.ingredient)}
                    className="text-gray-400 hover:text-red-600 transition-colors duration-200"
                    title={translations.report_inaccuracy}
                    aria-label={`${translations.report_inaccuracy} for ${result.ingredient}`}
                >
                    <ThumbsDownIcon className="w-4 h-4" />
                </button>
            </div>
          </div>
          <p className="mt-1 text-sm opacity-80">{result.reason}</p>
        </div>
      </div>
    </div>
  );
};