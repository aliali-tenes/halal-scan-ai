import React from 'react';
import { ResultCard } from './ResultCard';
import type { AnalysisResult } from '../types';

interface OnboardingDemoResultsProps {
    translations: { [key: string]: any };
}

export const OnboardingDemoResults: React.FC<OnboardingDemoResultsProps> = ({ translations }) => {

    const demoResults: AnalysisResult[] = [
        {
            ingredient: translations.demo_halal_ingredient,
            status: 'Halal',
            reason: translations.demo_halal_reason,
        },
        {
            ingredient: translations.demo_haram_ingredient,
            status: 'Haram',
            reason: translations.demo_haram_reason,
        },
        {
            ingredient: translations.demo_mushbooh_ingredient,
            status: 'Mushbooh',
            reason: translations.demo_mushbooh_reason,
        }
    ];

    return (
        <div className="mt-8" data-tour-id="result-card-demo">
            <h2 className="text-2xl font-bold mb-4">{translations.analysis_results}</h2>
            <div className="space-y-4 pointer-events-none">
                {demoResults.map((result, index) => (
                    <ResultCard
                        key={index}
                        result={result}
                        index={index}
                        translations={translations}
                        onReportInaccuracy={() => {}}
                    />
                ))}
            </div>
        </div>
    );
};