
import React from 'react';
import type { AnalysisResult } from '../types';
import { ShareIcon } from './icons/ShareIcon';

interface ShareButtonProps {
  results: AnalysisResult[];
  translations: { [key: string]: any };
}

export const ShareButton: React.FC<ShareButtonProps> = ({ results, translations }) => {
  const handleShare = async () => {
    if (!navigator.share) {
      alert('Share feature is not supported in your browser.');
      return;
    }

    let shareText = `${translations.share_text_title}\n`;
    shareText += `${translations.share_text_summary(results.length)}\n\n`;

    results.forEach(result => {
        const status = result.status;
        const statusEmoji = status === 'Halal' ? '✅' : status === 'Haram' ? '❌' : '❓';
        shareText += `${statusEmoji} ${result.ingredient}: ${status}\nReason: ${result.reason}\n\n`;
    });
    
    shareText += `${translations.footer_disclaimer}`;


    try {
      await navigator.share({
        title: translations.share_text_title,
        text: shareText,
      });
    } catch (error) {
      // The user canceling the share dialog is not a bug.
      // We check for the specific AbortError and ignore it to avoid console noise.
      if (error instanceof Error && error.name === 'AbortError') {
        console.log('Share was cancelled by the user.');
      } else {
        console.error('Error sharing:', error);
      }
    }
  };

  return (
    <button
      onClick={handleShare}
      className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition duration-200"
    >
      <ShareIcon className="w-5 h-5" />
      {translations.share_results}
    </button>
  );
};
