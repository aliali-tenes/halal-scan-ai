import React, { useState, useEffect, useRef } from 'react';
import type { Status } from '../types';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (feedback: { correctStatus: Status; comments: string }) => void;
  ingredientName: string | null;
  translations: { [key: string]: any };
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose, onSubmit, ingredientName, translations }) => {
  const [correctStatus, setCorrectStatus] = useState<Status | ''>('');
  const [comments, setComments] = useState('');
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      // Reset form on open
      setCorrectStatus('');
      setComments('');
      modalRef.current?.focus();
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (correctStatus) {
      onSubmit({ correctStatus, comments });
    }
  };
  
  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="feedback-modal-title"
      onClick={onClose}
    >
      <div
        ref={modalRef}
        className="bg-white rounded-2xl shadow-2xl p-6 md:p-8 max-w-md w-full transform transition-all scale-100 opacity-100"
        tabIndex={-1}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="feedback-modal-title" className="text-xl font-bold text-gray-800 mb-2">
          {translations.feedback_modal_title} <span className="text-brand-green">"{ingredientName}"</span>
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="my-4 text-left">
            <label htmlFor="correct-status" className="block text-sm font-medium text-gray-700 mb-1">
              {translations.correct_status_label}
            </label>
            <select
              id="correct-status"
              value={correctStatus}
              onChange={(e) => setCorrectStatus(e.target.value as Status)}
              required
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-green focus:outline-none transition duration-200"
            >
              <option value="" disabled>{translations.select_status}</option>
              <option value="Halal">{translations.status_halal}</option>
              <option value="Haram">{translations.status_haram}</option>
              <option value="Mushbooh">{translations.status_mushbooh}</option>
            </select>
          </div>
          <div className="mb-6 text-left">
            <label htmlFor="comments" className="block text-sm font-medium text-gray-700 mb-1">
              {translations.comments_label}
            </label>
            <textarea
              id="comments"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              rows={3}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-green focus:outline-none transition duration-200"
            />
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-4 rounded-lg transition duration-200"
            >
              {translations.cancel_button}
            </button>
            <button
              type="submit"
              disabled={!correctStatus}
              className="flex-1 bg-brand-green hover:bg-brand-green-dark text-white font-bold py-3 px-4 rounded-lg transition duration-200 disabled:bg-green-200"
            >
              {translations.submit_feedback_button}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
