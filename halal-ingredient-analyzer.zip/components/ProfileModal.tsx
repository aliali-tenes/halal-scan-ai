import React, { useState, useEffect, useRef } from 'react';
import type { Language, UserProfile } from '../types';
import { UserIcon } from './icons/UserIcon';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (profile: UserProfile) => void;
  currentUserProfile: UserProfile;
  translations: { [key: string]: any };
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose, onSave, currentUserProfile, translations }) => {
  const [profile, setProfile] = useState<UserProfile>(currentUserProfile);
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setProfile(currentUserProfile);
  }, [currentUserProfile, isOpen]);

  useEffect(() => {
    if (isOpen) {
      modalRef.current?.focus();
    }
  }, [isOpen]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(profile);
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="profile-modal-title"
      onClick={onClose}
    >
      <div
        ref={modalRef}
        className="bg-white rounded-2xl shadow-2xl p-6 md:p-8 max-w-md w-full transform transition-all"
        tabIndex={-1}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-green-100 rounded-full">
            <UserIcon className="w-6 h-6 text-brand-green" />
          </div>
          <h2 id="profile-modal-title" className="text-xl font-bold text-gray-800">
            {translations.profile_modal_title}
          </h2>
        </div>
        <form onSubmit={handleSave}>
          <div className="my-4 text-left">
            <label htmlFor="language-select" className="block text-sm font-medium text-gray-700 mb-1">
              {translations.language_label}
            </label>
            <select
              id="language-select"
              value={profile.language}
              onChange={(e) => setProfile({ ...profile, language: e.target.value as Language })}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-green focus:outline-none transition duration-200"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
            </select>
          </div>
          <div className="mb-6 text-left">
            <label htmlFor="concerns" className="block text-sm font-medium text-gray-700 mb-1">
              {translations.concerns_label}
            </label>
            <textarea
              id="concerns"
              value={profile.concerns}
              onChange={(e) => setProfile({ ...profile, concerns: e.target.value })}
              rows={3}
              placeholder={translations.concerns_placeholder}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-green focus:outline-none transition duration-200"
            />
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-4 rounded-lg transition duration-200"
            >
              {translations.cancel_button}
            </button>
            <button
              type="submit"
              className="flex-1 bg-brand-green hover:bg-brand-green-dark text-white font-bold py-3 px-4 rounded-lg transition duration-200"
            >
              {translations.save_button}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
