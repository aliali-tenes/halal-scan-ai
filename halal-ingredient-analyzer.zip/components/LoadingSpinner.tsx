
import React from 'react';

interface LoadingSpinnerProps {
    translations: { [key: string]: any };
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ translations }) => {
  return (
    <div className="flex flex-col items-center justify-center my-8">
      <div className="w-12 h-12 border-4 border-brand-green border-t-transparent rounded-full animate-spin"></div>
      <p className="mt-4 text-lg text-gray-600">{translations.loading}</p>
    </div>
  );
};
