import React, { useState, useEffect, useLayoutEffect, useRef } from 'react';

interface TourStep {
  selector: string;
  title: string;
  content: string;
}

interface OnboardingProps {
  isOpen: boolean;
  steps: TourStep[];
  onComplete: () => void;
  onStepChange: (step: number) => void;
  translations: { [key: string]: any };
}

const Onboarding: React.FC<OnboardingProps> = ({ isOpen, steps, onComplete, onStepChange, translations }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [highlightStyle, setHighlightStyle] = useState({});
  const [tooltipStyle, setTooltipStyle] = useState({});
  const tooltipRef = useRef<HTMLDivElement>(null);
  
  const step = steps[currentStep];

  useLayoutEffect(() => {
    if (isOpen && step?.selector) {
      const element = document.querySelector(step.selector);
      if (element) {
        const rect = element.getBoundingClientRect();
        const padding = 10;
        
        setHighlightStyle({
          width: `${rect.width + padding}px`,
          height: `${rect.height + padding}px`,
          top: `${rect.top - padding / 2}px`,
          left: `${rect.left - padding / 2}px`,
        });

        // Position tooltip
        const tooltipHeight = tooltipRef.current?.offsetHeight || 150;
        const spaceBelow = window.innerHeight - rect.bottom;
        
        if (spaceBelow > tooltipHeight + 20) {
            // Position below
            setTooltipStyle({
                top: `${rect.bottom + 15}px`,
                left: `${rect.left}px`,
                right: 'auto',
                width: `${rect.width}px`,
                minWidth: '250px',
            });
        } else {
            // Position above
            setTooltipStyle({
                top: `${rect.top - tooltipHeight - 15}px`,
                left: `${rect.left}px`,
                right: 'auto',
                width: `${rect.width}px`,
                minWidth: '250px',
            });
        }
      }
    }
  }, [isOpen, currentStep, step]);

  useEffect(() => {
    if (isOpen) {
        onStepChange(currentStep);
    }
  }, [isOpen, currentStep, onStepChange]);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50">
      {/* Overlay */}
      <div className="fixed inset-0 bg-black bg-opacity-70 transition-opacity duration-300"></div>

      {/* Spotlight */}
      <div
        className="fixed border-2 border-white rounded-lg shadow-2xl transition-all duration-300 ease-in-out"
        style={{ ...highlightStyle, boxShadow: '0 0 0 9999px rgba(0,0,0,0.7)' }}
      ></div>

      {/* Tooltip */}
      <div ref={tooltipRef} className="fixed z-[60] bg-white rounded-lg p-5 shadow-xl max-w-sm transition-all duration-300 ease-in-out" style={tooltipStyle}>
        <h3 className="text-xl font-bold mb-2 text-gray-800">{step.title}</h3>
        <p className="text-gray-600 mb-4">{step.content}</p>
        <div className="flex justify-between items-center">
          <button onClick={onComplete} className="text-sm text-gray-500 hover:text-gray-800 transition-colors">
            {translations.onboarding_skip}
          </button>
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-gray-500">{currentStep + 1} / {steps.length}</span>
            {currentStep > 0 && (
              <button onClick={handlePrev} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-md hover:bg-gray-300 transition-colors">
                {translations.onboarding_prev}
              </button>
            )}
            <button onClick={handleNext} className="bg-brand-green text-white font-bold py-2 px-4 rounded-md hover:bg-brand-green-dark transition-colors">
              {currentStep === steps.length - 1 ? translations.onboarding_finish : translations.onboarding_next}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export { Onboarding };