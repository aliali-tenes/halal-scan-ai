import React, { useState, useRef, useEffect } from 'react';
import { RotateCwIcon } from './icons/RotateCwIcon';
import { CropIcon } from './icons/CropIcon';
import { XCircleIcon } from './icons/XCircleIcon';
// Added missing SparklesIcon import to fix the "Cannot find name 'SparklesIcon'" error
import { SparklesIcon } from './icons/SparklesIcon';

interface ImageEditorProps {
  imageSrc: string;
  onConfirm: (editedImageBase64: string) => void;
  onClose: () => void;
  translations: { [key: string]: any };
}

export const ImageEditor: React.FC<ImageEditorProps> = ({ imageSrc, onConfirm, onClose, translations }) => {
  const [rotation, setRotation] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [imgElement, setImgElement] = useState<HTMLImageElement | null>(null);

  useEffect(() => {
    const img = new Image();
    img.src = imageSrc;
    img.onload = () => {
      setImgElement(img);
      draw(img, 0);
    };
  }, [imageSrc]);

  const draw = (img: HTMLImageElement, rot: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const angleInRad = (rot * Math.PI) / 180;
    const isVertical = rot % 180 !== 0;

    const width = isVertical ? img.height : img.width;
    const height = isVertical ? img.width : img.height;

    // Limit maximum size for processing to keep it snappy
    const MAX_DIM = 2000;
    let scale = 1;
    if (width > MAX_DIM || height > MAX_DIM) {
        scale = MAX_DIM / Math.max(width, height);
    }

    canvas.width = width * scale;
    canvas.height = height * scale;

    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(angleInRad);
    ctx.drawImage(
      img,
      -img.width * scale / 2,
      -img.height * scale / 2,
      img.width * scale,
      img.height * scale
    );
    ctx.restore();
  };

  const handleRotate = () => {
    const nextRotation = (rotation + 90) % 360;
    setRotation(nextRotation);
    if (imgElement) {
      draw(imgElement, nextRotation);
    }
  };

  const handleConfirm = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      const base64 = dataUrl.split(',')[1];
      onConfirm(base64);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black bg-opacity-90 flex flex-col p-4">
      <div className="flex justify-between items-center mb-4 text-white">
        <h2 className="text-xl font-bold">{translations.image_editor_title}</h2>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <XCircleIcon className="w-8 h-8" />
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-gray-900 rounded-xl border border-gray-700">
        <div ref={containerRef} className="max-w-full max-h-full">
            <canvas ref={canvasRef} className="max-w-full max-h-full object-contain shadow-2xl" />
        </div>
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/50 px-4 py-2 rounded-full text-white text-sm pointer-events-none">
            {translations.image_editor_instructions}
        </div>
      </div>

      <div className="mt-6 flex gap-4">
        <button
          onClick={handleRotate}
          className="flex-1 flex items-center justify-center gap-2 bg-gray-700 hover:bg-gray-600 text-white font-bold py-4 px-4 rounded-xl transition duration-200"
        >
          <RotateCwIcon className="w-6 h-6" />
          {translations.rotate_button}
        </button>
        <button
          onClick={handleConfirm}
          className="flex-1 flex items-center justify-center gap-2 bg-brand-green hover:bg-brand-green-dark text-white font-bold py-4 px-4 rounded-xl transition duration-200 shadow-lg"
        >
          <SparklesIcon className="w-6 h-6" />
          {translations.crop_confirm}
        </button>
      </div>
    </div>
  );
};