import React, { useEffect } from 'react';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

interface ToastProps {
  message: string;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 4000); // Hide after 4 seconds

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div
      className="fixed bottom-5 right-5 bg-brand-green text-white py-3 px-5 rounded-lg shadow-lg z-50 flex items-center gap-3 animate-fade-in-up"
      role="alert"
    >
      <CheckCircleIcon className="w-6 h-6" />
      <p className="font-medium">{message}</p>
    </div>
  );
};
