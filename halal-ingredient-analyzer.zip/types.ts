export type Status = 'Halal' | 'Haram' | 'Mushbooh';

export interface AnalysisResult {
  ingredient: string;
  status: Status;
  reason: string;
}

export type Language = 'en' | 'ar' | 'fr';

export interface UserProfile {
  language: Language;
  concerns: string;
}
